﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Message
{
    private long _id;
    private string _from;
    private long _mobileNumber;
    private string _content;
    private double _size;
    private DateTime _postedDate;

    public DateTime PostedDate
    {
        get { return _postedDate; }
        set { _postedDate = value; }
    }

    public double Size
    {
        get { return _size; }
        set { _size = value; }
    }

    public string Content
    {
        get { return _content; }
        set { _content = value; }
    }

    public long MobileNumber
    {
        get { return _mobileNumber; }
        set { _mobileNumber = value; }
    }

    public string From
    {
        get { return _from; }
        set { _from = value; }
    }

    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    public Message()
    {

    }
    public Message(long _id, string _from, long _mobileNumber, string _content, double _size, DateTime _postedDate)
    {
        this.Id = _id;
        this.From = _from;
        this.MobileNumber = _mobileNumber;
        this.Content = _content;
        this.Size = _size;
        this.PostedDate = _postedDate;
    }

    public override string ToString()
    {
        return string.Format("Id:{0}\nFrom:{1}\nMobile Number:{2}\nContent:{3}\nSize:{4}\nPosted Date:{5}", Id, From, MobileNumber, Content, Size.ToString("0.0"), PostedDate.ToString("dd-MM-yyyy"));
    }

    public override bool Equals(object obj)
    {
        Message m = (Message)obj;

        if (this.From.Equals(m.From, StringComparison.InvariantCultureIgnoreCase) && this.MobileNumber.Equals(m.MobileNumber))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}

