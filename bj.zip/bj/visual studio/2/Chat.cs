﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Chat
    {
        string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        List<Message> _messageList;

        internal List<Message> MessageList
        {
            get { return _messageList; }
            set { _messageList = value; }
        }

        public Chat()
        {
                
        }
        public Chat(string _name, List<Message> _messageList)
        {
            this._name = _name;
            this._messageList = _messageList;
        }

        public void AddMessageToChat(Message messageObj)
        {
            MessageList.Add(messageObj);
        }
        public bool RemoveMessage(long id)
        {
            foreach (var item in MessageList)
            {
                if (item.Id == id)
                {
                    MessageList.Remove(item);
                    return true;
                }
            }
            return false;
        }
        public void DisplayMessages()
        {
            if (MessageList.Count == 0)
                Console.WriteLine("No messages to show");
            else
            {
                Console.WriteLine("Messages in {0}", Name);
                Console.WriteLine("{0,-5} {1,-8} {2,-15} {3,-45} {4,-5} {5}", "Id", "From", "Mobile Number", "Content", "Size", "Posted Date");
                foreach (var item in MessageList)
                {                    
                    Console.WriteLine(item.ToString());
                }
            }
        }
    }

