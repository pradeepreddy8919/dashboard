﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Message:IComparable<Message>
{
    //fill code here

    private long _id;

    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    private string _from;

    public string From
    {
        get { return _from; }
        set { _from = value; }
    }
    private long _mobileNumber;

    public long MobileNumber
    {
        get { return _mobileNumber; }
        set { _mobileNumber = value; }
    }
    private string _content;

    public string Content
    {
        get { return _content; }
        set { _content = value; }
    }
    private double _size;

    public double Size
    {
        get { return _size; }
        set { _size = value; }
    }
    private DateTime _postedDate;

    public DateTime PostedDate
    {
        get { return _postedDate; }
        set { _postedDate = value; }
    }
    public Message()
    {

    }
    public Message(long _id, string _from, long _mobileNumber, string _content, double _size, DateTime _postedDate)
    {
        this._id = _id;
        this._from = _from;
        this._mobileNumber = _mobileNumber;
        this._content = _content;
        this._size = _size;
        this._postedDate = _postedDate;
    }



    public static Message CreateMessage(string details)
    {
        //fill code here
        string[] s = details.Split(',');
        return new Message(Convert.ToInt64(s[0]), s[1], Convert.ToInt64(s[2]),s[3],double.Parse(s[4]),DateTime.ParseExact(s[5],"dd-MM-yyyy",null));

    }

    public int CompareTo(Message other)
    {
        return this.Size.CompareTo(other.Size);
    }
}