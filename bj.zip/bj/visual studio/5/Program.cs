﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        List<Message> messageList = new List<Message>();
        Console.WriteLine("Enter the number of messages:");
        int count = Convert.ToInt32(Console.ReadLine());
        //fill code here
        for (int i = 0; i < count; i++)
        {
            string s = Console.ReadLine();
            messageList.Add(Message.CreateMessage(s));
        }

        Console.WriteLine("Enter a type to sort:\n1.Sort by Size\n2.Sort by Posted Date");
        int ch = int.Parse(Console.ReadLine());
        Console.WriteLine("{0,-5} {1,-8} {2,-15} {3,-45} {4,-5} {5}", "Id", "From", "Mobile Number", "Content", "Size", "Posted Date");
        if (ch == 1)
        {
            messageList.Sort();
            foreach (var item in messageList)
            {
                Console.WriteLine("{0,-5} {1,-8} {2,-15} {3,-45} {4,-5} {5}", item.Id, item.From, item.MobileNumber, item.Content, item.Size.ToString("0.0"), item.PostedDate.ToString("dd-MM-yyyy"));   
            }
        }
        else if (ch == 2)
        {
            PostedDateComparer p = new PostedDateComparer();
            messageList.Sort(p);
            foreach (var item in messageList)
            {
                Console.WriteLine("{0,-5} {1,-8} {2,-15} {3,-45} {4,-5} {5}", item.Id, item.From, item.MobileNumber, item.Content, item.Size.ToString("0.0"), item.PostedDate.ToString("dd-MM-yyyy"));
            }

        }




        Console.ReadLine();
        
        //fill code here
    }
}