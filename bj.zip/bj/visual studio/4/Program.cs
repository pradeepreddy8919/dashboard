﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            List<Message> playerList = new List<Message>();
            List<Message> pb = new List<Message>();
            int noOfPlayer, choice;
            MessageBO pb1 = new MessageBO();
            Console.WriteLine("Enter the number of messages:");
            noOfPlayer = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < noOfPlayer; i++)
            {                
                string x = Console.ReadLine();
                Message st = Message.CreateMessage(x);
                playerList.Add(st);
            }
            Console.WriteLine("Enter a search type:\n" +
                    "1.By Content\n" +
                    "2.By Posted Date");
            choice = Convert.ToInt32(Console.ReadLine());
            if (choice == 1)
            {
                Console.WriteLine("Enter the Content:");
                string name = Console.ReadLine();
                
                pb = pb1.FindMessage(playerList, name);

                if (pb.Count == 0)
                {
                    Console.WriteLine("No such message is present");
                }
                else
                {
                    Console.WriteLine("{0,-5} {1,-8} {2,-15} {3,-45} {4,-5} {5}", "Id", "From", "Mobile Number", "Content", "Size", "Posted Date");
                    foreach (var item in pb)
                    {
                        Console.WriteLine("{0,-5} {1,-8} {2,-15} {3,-45} {4,-5} {5}", item.Id, item.From, item.MobileNumber, item.Content, item.Size.ToString("0.0"), item.PostedDate.ToString("dd-MM-yyyy"));
                    }
                }

            }
            else if (choice == 2)
            {
                Console.WriteLine("Enter the Posted Date:");
                DateTime d = DateTime.ParseExact(Console.ReadLine(), "dd-MM-yyyy", null);
                
                pb = pb1.FindMessage(playerList, d);

                if (pb.Count == 0)
                {
                    Console.WriteLine("No such message is present");
                }
                else
                {
                    Console.WriteLine("{0,-5} {1,-8} {2,-15} {3,-45} {4,-5} {5}", "Id", "From", "Mobile Number", "Content", "Size", "Posted Date");
                    foreach (var item in pb)
                    {
                        Console.WriteLine("{0,-5} {1,-8} {2,-15} {3,-45} {4,-5} {5}", item.Id, item.From, item.MobileNumber, item.Content, item.Size.ToString("0.0"), item.PostedDate.ToString("dd-MM-yyyy"));
                    }
                }
            }

            else
            {
                Console.WriteLine("Invalid choice");
            }
        }
    }

