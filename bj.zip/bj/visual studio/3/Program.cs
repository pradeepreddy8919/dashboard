﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the content to be reviewed:");
        string s = Console.ReadLine();
        if (IsSpam(s))
            Console.WriteLine("Content is not a spam");
        else
            Console.WriteLine("Content is a spam");
    }
    static bool IsSpam(string content)
    {
        int r = 0;
        int c = 0;
        for (int i = 0; i < content.Length; i++)
        {
            if (content[i] != ' ')
            {
                c++;
            }
        }

        for (int i = 0; i < content.Length - 2; i++)
        {
            if (content[i] == content[i + 1] && content[i] == content[i + 2])
                r++;
        }

        if (r == 0 && c <35)
            return true;
        else
            return false;
    }
}