﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        //List<Locker> lockerList = new List<Locker>();
        List<Message> m = new List<Message>();
        Console.WriteLine("Enter the number of messages");
        //fill code here
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            String[] s = Console.ReadLine().Split(',');
            m.Add(new Message(long.Parse(s[0]), s[1], long.Parse(s[2]), s[3], double.Parse(s[4]), DateTime.ParseExact(s[5], "dd-MM-yyyy", null)));
        }


        SortedDictionary<DateTime, int> sd = Message.MessagesPerDate(m);

        Console.WriteLine("{0,-15} {1}", "Date", "Count");
        foreach (var item in sd)
        {
            Console.WriteLine("{0,-15} {1}",item.Key.ToString("dd-MM-yyyy"),item.Value);
            
        }
    }
}