﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace mfrp
{
    public class FaceDao
    {
        public  void connection()
        {
        }
        public void load_GridView()
        {
        }
        public void load_id()
        {
        }

        public void load_OrderDate()
        {
        }
    }
}