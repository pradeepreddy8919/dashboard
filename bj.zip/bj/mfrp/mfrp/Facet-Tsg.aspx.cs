﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace mfrp.pages
{
    public partial class Facet_Tsg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select o.order_id,c.customername,convert(varchar(12) ,Order_Date,103) OrderDate,e.employeename,convert(varchar(12), o.estimated_date,103) EstimatedDate,convert(varchar(12),i.invoice_date,103) InvoiceDate from invoice i join orderr o on i.order_id=o.order_id join customer c on i.cid=c.cid join employee e on i.eid=e.eid where tsg_status=1", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        { 
            GridView1.Visible = false;
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select o.order_id,c.customername,convert(varchar(12) ,Order_Date,103) OrderDate,e.employeename,convert(varchar(12), o.estimated_date,103) EstimatedDate,convert(varchar(12),i.invoice_date,103) InvoiceDate from invoice i join orderr o on i.order_id=o.order_id join customer c on i.cid=c.cid join employee e on i.eid=e.eid where tsg_status=1 and invoice_id=@iid", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            sc.Parameters.AddWithValue("@iid", int.Parse(DropDownList1.SelectedValue.ToString()));
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
        }

        protected void txtPickupDate_TextChanged(object sender, EventArgs e)
        {

            DateTime date = DateTime.Parse(txtPickupDate.Text.ToString());


            GridView1.Visible = false;
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select o.order_id,c.customername,convert(varchar(12) ,Order_Date,103) OrderDate,e.employeename,convert(varchar(12), o.estimated_date,103) EstimatedDate,convert(varchar(12),i.invoice_date,103) InvoiceDate from invoice i join orderr o on i.order_id=o.order_id join customer c on i.cid=c.cid join employee e on i.eid=e.eid where tsg_status=1 and order_date=@date", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            sc.Parameters.AddWithValue("@date", date);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
        }
    }
}