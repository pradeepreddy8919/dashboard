create database facets
use facets
create table customer (cid int primary key not null,customername varchar(50) not null,cust_mobno int not null,cust_email varchar(50) not null)
insert into customer values(1,'Likhitha',1231231234,'likhitha@abc.com'),(2,'Sundhar',1237894566,'sundhar@cv.in'),
(3,'Shivani',4561237899,'shivani@fie.fj'),(4,'Surya',8885552222,'surya@ghj.in'),(5,'Harshitha',7755339999,'harshitha@tyu.io'),
(6,'Pandey',7778889999,'pandey@567.com'),(7,'Teja',8989782222,'teja@pulihararaja.com'),
(8,'Pradeep',8899662233,'pradeep@rider.com'),(9,'Chakri',8866332233,'chakri@yui.com'),
(10,'Rohith',7894564213,'rs1611@fklja.in')
drop table customer
create table customer (cid int primary key not null,customername varchar(50) not null,cust_mobno varchar(50) not null,cust_email varchar(50) not null)
insert into customer values(1,'Likhitha',1231231234,'likhitha@abc.com'),(2,'Sundhar',1237894566,'sundhar@cv.in'),
(3,'Shivani',4561237899,'shivani@fie.fj'),(4,'Surya',8885552222,'surya@ghj.in'),(5,'Harshitha',7755339999,'harshitha@tyu.io'),
(6,'Pandey',7778889999,'pandey@567.com'),(7,'Teja',8989782222,'teja@pulihararaja.com'),
(8,'Pradeep',8899662233,'pradeep@rider.com'),(9,'Chakri',8866332233,'chakri@yui.com'),
(10,'Rohith',7894564213,'rs1611@fklja.in')
create table employee (eid int primary key not null,employeename varchar(50) not null)
insert into employee values(1,'Ramya'),(2,'Phaneedra'),
(3,'Sai Teja'),(4,'Anvesh'),(5,'Trilokya'),
(6,'Poojitha'),(7,'Vamshi'),
(8,'Sai Kiran'),(9,'Uday'),
(10,'Sri devi')
create table orderr (order_id int primary key not null,order_date date not null,estimated_date date not null,amount int not null)
insert into orderr values(1,'2019-03-01','2019-03-04','1500'),(2,'2019-03-01','2019-03-04',2500),(3,'2019-03-01','2019-03-04',1425),
(4,'2019-03-01','2019-03-04',7410),(5,'2019-03-01','2019-03-04',1230),(6,'2019-03-11','2019-03-14',5520),
(7,'2019-03-11','2019-03-14',5211),(8,'2019-03-11','2019-03-14',1144),(9,'2019-03-11','2019-03-14',5210),
(10,'2019-03-11','2019-03-14',2230)
create table invoice (invoice_id int primary key not null,cid int foreign key references customer(cid),eid int foreign key references employee(eid),order_id int foreign key references orderr(order_id),invoice_date date)
insert into invoice values(001,1,1,1,'2019-03-04'),(002,2,2,2,'2019-03-04'),(003,3,3,3,'2019-03-04'),(004,4,4,4,'2019-03-14'),
(005,5,5,5,'2019-03-14'),(006,6,6,6,'2019-03-14'),(007,7,7,7,'2019-03-05'),(008,8,8,8,'2019-03-05'),
(009,9,9,9,'2019-03-15'),(010,10,10,10,'2019-03-15')
ALTER TABLE invoice ADD tsg_status int 
ALTER TABLE invoice ADD soft_status int
update invoice set tsg_status=0 where invoice_id=1
select * from invoice
select * from orderr
update invoice set soft_status=0 where invoice_id=1
update invoice set tsg_status=0,soft_status=0 where invoice_id=10
update invoice set tsg_status=1 where order_id=9 and invoice_date<=(select estimated_date from orderr where order_id=9)
update invoice set invoice_date='2019-03-14' where invoice_id=9
select count(tsg_status) from invoice where tsg_status=1