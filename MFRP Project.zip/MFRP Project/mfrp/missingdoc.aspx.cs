﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;

namespace mfrp
{
    public partial class missingdox : System.Web.UI.Page
    {


        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {

            ds = MissingDao.load_GridView();
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
        }

        protected void txtPickupDate_TextChanged(object sender, EventArgs e)
        {
            Response.Write(txtPickupDate.Text);
            GridView1.Visible = false;
            DateTime date = Convert.ToDateTime(txtPickupDate.Text);
            DataSet ds = MissingDao.load_due_Date(date);
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id = TextBox1.Text.ToString();
            int s;
            if (id == "")
            {
                s = 0;
            }
            else
            {
                s = int.Parse(TextBox1.Text.ToString());
            }
            DataSet ds1 = MissingDao.load_id(s);
            GridView1.DataSource = ds1.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
        }
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.DataSource = ds.Tables[0];


            GridView1.DataBind();
            GridView1.Visible = true;
            GridView1.PageIndex = e.NewPageIndex;


        }

        protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
        {
            string s = DropDownList4.SelectedValue.ToString();

            DataSet ds1 = MissingDao.load_filetype(s);
            GridView1.DataSource = ds1.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
        }


        protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dt = ds.Tables[0];
            if (dt != null)
            {
                dt.DefaultView.Sort = e.SortExpression + " " + "ASC";
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }
       
    }
}
