﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
namespace mfrp
{
    public class MissingDao
    {
        public void connection()
        {
        }
        public static DataSet load_GridView()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select invoice_number Invoice_Number,convert(varchar(12),due_date,103) Due_Date,concat('$',due_amount) as Due_Amount,member_id Member_ID,name Name,TSGfilename,file_type File_Type from facets where invoice_number not in (select invoice_number from TsgSoftheon)", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            return ds;
        }
        public static DataSet load_id(int id)
        {

            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc;
            if (id == 0)
            {
                sc = new SqlCommand("select invoice_number Invoice_Number,convert(varchar(12),due_date,103) Due_Date,concat('$',due_amount) as Due_Amount,member_id Member_ID,name Name,TSGfilename,file_type File_Type from facets where invoice_number not in (select invoice_number from TsgSoftheon) ", cn);
            }
            else
            {
                sc = new SqlCommand("select invoice_number Invoice_Number,convert(varchar(12),due_date,103) Due_Date,concat('$',due_amount) as Due_Amount,member_id Member_ID,name Name,TSGfilename,file_type File_Type from facets where invoice_number not in (select invoice_number from TsgSoftheon) and invoice_number=@iid", cn);
                sc.Parameters.AddWithValue("@iid", id);
            }
            SqlDataAdapter da = new SqlDataAdapter(sc);

            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            return ds;
        }
        public static DataSet load_filetype(string type)
        {
            string x = "";
            if (type == "A")
            {
                x = "a";
            }
            else if (type == "B")
            {
                x = "b";
            }
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select invoice_number Invoice_Number,convert(varchar(12),due_date,103) Due_Date,concat('$',due_amount) as Due_Amount,member_id Member_ID,name Name,TSGfilename,file_type File_Type from facets where invoice_number not in (select invoice_number from TsgSoftheon) and file_type=@iid", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            sc.Parameters.AddWithValue("@iid", x);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            return ds;

        }
        public static DataSet load_due_Date(DateTime type)
        {

            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select invoice_number as Invoice_Number,convert(varchar(12),due_date,103) as Due_Date,concat('$',due_amount) as Due_Amount,member_id as Member_ID,name as Name,TSGfilename,file_type as File_Type  from facets where invoice_number not in (select invoice_number from TsgSoftheon) and due_date=@date", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            sc.Parameters.AddWithValue("@date", type);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            return ds;

        }
    }
}