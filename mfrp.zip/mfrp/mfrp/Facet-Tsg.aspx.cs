﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace mfrp.pages
{
    public partial class Facet_Tsg : System.Web.UI.Page
    {
        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {
            ds = FaceDao.load_GridView();
            GridView1.DataSource = ds.Tables[0];

           // GridView1.EnableSortingAndPagingCallbacks = true;
            GridView1.DataBind();
            GridView1.Visible = true;
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridView1.Visible = false;
            int ID = 0;
            if (TextBox1.Text == "")
            {
                ID = 0;
            }
            else
            {
                ID = int.Parse(TextBox1.Text);
            }
            DataSet ds = FaceDao.load_id(ID);

            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
           
        }

        protected void txtPickupDate_TextChanged(object sender, EventArgs e)
        {

            Response.Write(txtPickupDate.Text);
            GridView1.Visible = false;
            DateTime date =Convert.ToDateTime( txtPickupDate.Text);
            DataSet ds = FaceDao.load_due_Date(date);
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
        }

    
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.DataSource = ds.Tables[0];

          
            GridView1.DataBind();
            GridView1.Visible = true;
            GridView1.PageIndex = e.NewPageIndex;
           
            
        }
        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string s = DropDownList2.SelectedValue.ToString();
            DataSet ds1 = FaceDao.load_filetype(s);
            GridView1.DataSource = ds1.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
            
        }

        protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dt = ds.Tables[0];
            if(dt!=null)
            {
                dt.DefaultView.Sort = e.SortExpression + " " + "ASC";
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }
      
    }
}