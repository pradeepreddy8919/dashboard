﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace mfrp
{
    public class DashboardDAO
    {
        //public static DataSet load_count()
        //{
        //    //SqlConnection cn = new SqlConnection();
        //    //cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
        //    //SqlCommand sc = new SqlCommand("select due_date, count(invoice_number) count from facets group by Due_date", cn);
        //    //SqlDataAdapter da = new SqlDataAdapter(sc);
        //    //DataSet ds = new DataSet();
        //    //cn.Open();
        //    //da.Fill(ds);
        //    //cn.Close();

        //    //sc = new SqlCommand("select count(invoice_number)  count from facets", cn);
        //    //cn.Open();
        //    //int cnt = Convert.ToInt32(sc.ExecuteScalar());
        //    //cn.Close();
        //    ////a1.InnerText = cnt.ToString();
        //    //return ds;


        //}
    }
}