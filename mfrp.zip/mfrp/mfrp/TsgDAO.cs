﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace mfrp
{
    public class TsgDAO
    {
        public void connection()
        {
        }
        public static DataSet load_GridView()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select profileId as Profile_ID,invoice_number as Invoice_Number,convert(varchar(12),CreatedDate,103) as Created_Date from TsgSoftheon", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            return ds;
        }
        public static DataSet load_id(int id)
        {

            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc;
            if (id == 0)
            {
                sc = new SqlCommand("select profileId as Profile_ID,invoice_number as Invoice_Number,convert(varchar(12),CreatedDate,103) as Created_Date from TsgSoftheon ", cn);
            }
            else
            {
                sc = new SqlCommand("select profileId as Profile_ID,invoice_number as Invoice_Number,convert(varchar(12),CreatedDate,103) as Created_Date from TsgSoftheon where invoice_number=@iid", cn);
                sc.Parameters.AddWithValue("@iid", id);
            }
            SqlDataAdapter da = new SqlDataAdapter(sc);

            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            return ds;
        }

      
        public static DataSet load_due_Date(DateTime type)
        {

            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select profileId as Profile_ID,invoice_number as Invoice_Number,convert(varchar(12),CreatedDate,103) as Created_Date from TsgSoftheon where CreatedDate=@date", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            sc.Parameters.AddWithValue("@date", type);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            return ds;

        }

    }
}