﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace mfrp
{
    public class LoginDAO
    {
        public static SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["mycn"].ConnectionString);

   
        public static  bool  validate_Password(string uname,string password)
        {
        
        SqlCommand sc = new SqlCommand("select password from login where username=@name", cn);
        sc.Parameters.AddWithValue("@name",uname);

        try
        {
            cn.Open();
            SqlDataReader sdr = sc.ExecuteReader();
          string s;
            if (sdr.HasRows)
            {
                if (sdr.Read())
                {
                    s = sdr[0].ToString();
                    if (s.Equals(password)) { cn.Close(); return true; }
                    else
                    {
                        cn.Close();
                      return false;
                    }              
                }
            }
            else
            {
                cn.Close();
                return false;

            }
            cn.Close();
           return false;


        }
        catch (Exception ex)
        {
            return false;

        }
        finally
        {
            cn.Close();
        }
        }
    }
    }
