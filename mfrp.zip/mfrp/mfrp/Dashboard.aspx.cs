﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.DataVisualization.Charting;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace mfrp
{
    public partial class Dashboard : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select due_date, count(invoice_number) count from facets group by Due_date", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            //ds = DashboardDAO.load_count();
            sc = new SqlCommand("select count(invoice_number)  count from facets", cn);
            cn.Open();
            int cnt = Convert.ToInt32(sc.ExecuteScalar());
            cn.Close();
            a1.InnerText = cnt.ToString();



            SqlCommand sc1 = new SqlCommand("select CreatedDate, count(invoice_number) count from TsgSoftheon group by CreatedDate", cn);
            SqlDataAdapter da1 = new SqlDataAdapter(sc1);
            DataSet ds1 = new DataSet();
            cn.Open();
            da.Fill(ds1);
            cn.Close();

            sc1 = new SqlCommand("select count(invoice_number)  count from TsgSoftheon", cn);
            cn.Open();
            int cnt1 = Convert.ToInt32(sc1.ExecuteScalar());
            cn.Close();
            a2.InnerText = cnt1.ToString();



            SqlCommand sc2 = new SqlCommand("select count(invoice_number),convert(varchar(12),due_date,103),due_amount,member_id,name,TSGfilename,file_type count from facets where invoice_number not in (select invoice_number from TsgSoftheon)", cn);
            SqlDataAdapter da2 = new SqlDataAdapter(sc2);
            DataSet ds2 = new DataSet();
            cn.Open();
            da.Fill(ds2);
            cn.Close();

            sc2 = new SqlCommand("select count(invoice_number)  count from facets where invoice_number not in (select invoice_number from TsgSoftheon)", cn);
            cn.Open();
            int cnt2 = Convert.ToInt32(sc2.ExecuteScalar());
            cn.Close();
            a3.InnerText = cnt2.ToString();



            DataTable dt = ds.Tables[0];
            Chart1.DataSource = dt;
            Chart1.Series[0].ChartType = (SeriesChartType)10;
            Chart1.Legends[0].Enabled = true;
            Chart1.Series[0].XValueMember = "due_date";
            Chart1.Series[0].YValueMembers = "count";
            Chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            Chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            Chart1.DataBind();
           // Chart1.Visible = true;
            Chart1.Visible = true;
        
        }

        protected void Chart1_Load(object sender, EventArgs e)
        {

        //    SqlConnection cn = new SqlConnection();
        //    cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
        //    SqlCommand sc = new SqlCommand("select department_id,sum(salary) salary from employee group by department_id", cn);
        //    SqlDataAdapter da = new SqlDataAdapter(sc);
        //    DataSet ds = new DataSet();
        //    cn.Open();
        //    da.Fill(ds);
        //    cn.Close();
        //    DataTable dt = ds.Tables[0];
        //    Chart1.DataSource = dt;
        //    Chart1.Series[0].ChartType = (SeriesChartType)10;
        //    Chart1.Legends[0].Enabled = true;
        //    Chart1.Series[0].XValueMember = "Department_id";
        //    Chart1.Series[0].YValueMembers = "Salary";
        //    Chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
        //    Chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
        //    Chart1.DataBind();
        //   // Chart1.Visible = true;
        //    Chart1.Visible = true;
        //
}

    }
}