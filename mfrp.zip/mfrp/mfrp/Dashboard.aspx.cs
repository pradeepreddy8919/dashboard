﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.DataVisualization.Charting;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace mfrp
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select region_id,Count(name) as country from countries group by region_id", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            DataTable dt = ds.Tables[0];
            Chart1.DataSource = dt;
            Chart1.Series[0].ChartType = (SeriesChartType)10;
            Chart1.Legends[0].Enabled = true;
            Chart1.Series[0].XValueMember = "region_id";
            Chart1.Series[0].YValueMembers = "country";
            Chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            Chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            Chart1.DataBind();
           // Chart1.Visible = true;
            Chart1.Visible = true;
        
        }

        protected void Chart1_Load(object sender, EventArgs e)
        {

        //    SqlConnection cn = new SqlConnection();
        //    cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
        //    SqlCommand sc = new SqlCommand("select department_id,sum(salary) salary from employee group by department_id", cn);
        //    SqlDataAdapter da = new SqlDataAdapter(sc);
        //    DataSet ds = new DataSet();
        //    cn.Open();
        //    da.Fill(ds);
        //    cn.Close();
        //    DataTable dt = ds.Tables[0];
        //    Chart1.DataSource = dt;
        //    Chart1.Series[0].ChartType = (SeriesChartType)10;
        //    Chart1.Legends[0].Enabled = true;
        //    Chart1.Series[0].XValueMember = "Department_id";
        //    Chart1.Series[0].YValueMembers = "Salary";
        //    Chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
        //    Chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
        //    Chart1.DataBind();
        //   // Chart1.Visible = true;
        //    Chart1.Visible = true;
        //
}

    }
}